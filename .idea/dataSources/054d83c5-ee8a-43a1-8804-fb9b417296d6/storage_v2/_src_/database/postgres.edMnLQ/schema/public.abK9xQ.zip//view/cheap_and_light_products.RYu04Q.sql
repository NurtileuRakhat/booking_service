create view cheap_and_light_products(id, name, department, price, weight) as
SELECT id,
       name,
       department,
       price,
       weight
FROM products
WHERE price < 100::numeric
  AND weight < 10::numeric;

alter table cheap_and_light_products
    owner to postgres;

